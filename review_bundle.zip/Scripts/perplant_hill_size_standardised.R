#!/usr/bin/env Rscript
# =============================================================================
# perplant_hill_size_standardised.R
#
# Per-plant Hill diversity (TD and meanPD; q = 0, 1, 2) standardised to a
# common sequencing effort with iNEXT.3D (size-based rarefaction), followed by
# omnibus and post-hoc habitat tests taken from the SAME model.
#
# Replaces the Section 5.3 inputs (hillR on unrarefied summed counts) and fixes
# the mismatch between tests:
#   - Tables S14-S15 used anova() on log(y) ~ habitat * site. anova() on an lm
#     is sequential (Type I): habitat was tested first, NOT adjusted for site,
#     in a design where habitat and site are partly confounded (MA has no
#     forest, BEL no paramo).
#   - Table S15b Tukey contrasts came from log(y) ~ habitat + site, i.e.
#     habitat adjusted for site.
#   The omnibus and pairwise tests therefore asked different questions.
#
# Here, for each metric:
#   1. Parallelism: habitat x site interaction via anova(additive, interaction).
#   2. Omnibus habitat effect, adjusted for site: drop1() on the additive model.
#   3. Tukey pairwise contrasts (ratios) from the same additive model.
#   4. Polynomial (linear/quadratic) contrasts on ordered habitat: direction/shape.
# A diagnostic section re-fits the published unstandardised hillR q = 1 values
# with both Type I and site-adjusted tests to show the source of the mismatch.
#
# Run from the repository root:
#   Rscript Scripts/perplant_hill_size_standardised.R          # depth = min library
#   Rscript Scripts/perplant_hill_size_standardised.R 25000    # custom depth
#
# Inputs : objects/ps_individual.rds (per plant; root samples summed)
#          objects/tree_ps.rds       (ML tree)
# Outputs: objects/perplant_hill_size_std.rds
#          tables/perplant_hill_size_std_values.csv
#          tables/perplant_hill_size_std_omnibus.csv
#          tables/perplant_hill_size_std_pairwise.csv
#          tables/perplant_hill_size_std_trend.csv
#          tables/perplant_hill_size_std_emmeans.csv
#          tables/perplant_hill_published_typeI_vs_adjusted.csv (diagnostic)
# =============================================================================

suppressPackageStartupMessages({
  library(phyloseq)
  library(iNEXT.3D)
  library(ape)
  library(phangorn)
  library(dplyr)
  library(emmeans)
})

args        <- commandArgs(trailingOnly = TRUE)
out_tab_dir <- "tables"
out_obj_dir <- "objects"
dir.create(out_tab_dir, showWarnings = FALSE)

hab_levels <- c("forest", "subparamo", "paramo")
labs_map   <- c(forest = "Forest", subparamo = "Subpáramo", paramo = "Páramo")

message("iNEXT.3D version: ", as.character(packageVersion("iNEXT.3D")))

# ---- Load objects, shared tree ----------------------------------------------
ps_individual <- readRDS(file.path(out_obj_dir, "ps_individual.rds"))
tree_ps       <- readRDS(file.path(out_obj_dir, "tree_ps.rds"))

tr_full     <- phy_tree(tree_ps)
common_taxa <- intersect(taxa_names(ps_individual), tr_full$tip.label)
tr <- ape::keep.tip(tr_full, common_taxa)
tr$node.label <- NULL
if (!ape::is.rooted(tr)) tr <- phangorn::midpoint(tr)
reftime <- max(ape::node.depth.edgelength(tr))
message("Taxa in tree: ", length(common_taxa), " | PD reference time: ", signif(reftime, 5))

# ---- Community matrix (taxa x plants, summed read counts) --------------------
ps   <- prune_taxa(common_taxa, ps_individual)
comm <- as(otu_table(ps), "matrix")
if (!taxa_are_rows(ps)) comm <- t(comm)
comm <- comm[tr$tip.label, , drop = FALSE]
storage.mode(comm) <- "numeric"

meta <- as(sample_data(ps), "data.frame")[colnames(comm), , drop = FALSE]
meta$plant   <- colnames(comm)
meta$habitat <- factor(as.character(meta$habitat), levels = hab_levels)
meta$site    <- factor(as.character(meta$site))
stopifnot(!anyNA(meta$habitat), !anyNA(meta$site))

lib   <- colSums(comm)
DEPTH <- if (length(args) >= 1) as.numeric(args[1]) else min(lib)
if (DEPTH > min(lib)) warning("DEPTH exceeds the smallest library; some plants will be extrapolated.")

message("Plants: ", ncol(comm), " (", paste(names(table(meta$habitat)), table(meta$habitat),
                                          sep = "=", collapse = ", "), ")")
message("Library size range: ", min(lib), "-", max(lib), " | standardisation depth: ", DEPTH)
message("Singletons per plant (median [range]): ", median(colSums(comm == 1)),
        " [", min(colSums(comm == 1)), "-", max(colSums(comm == 1)), "]")

# ---- Size-standardised Hill numbers per plant -------------------------------
message("Estimating size-standardised TD ...")
est_td <- estimate3D(data = comm, diversity = "TD", q = c(0, 1, 2),
                     datatype = "abundance", base = "size", level = DEPTH, nboot = 0)
message("Estimating size-standardised PD (meanPD) ...")
est_pd <- estimate3D(data = comm, diversity = "PD", q = c(0, 1, 2),
                     datatype = "abundance", base = "size", level = DEPTH, nboot = 0,
                     PDtree = tr, PDreftime = reftime, PDtype = "meanPD")

pick_col <- function(df, exact, what) {
  hit <- exact[exact %in% names(df)]
  if (length(hit) == 0) stop("Cannot find ", what, " column. Columns: ",
                             paste(names(df), collapse = ", "))
  hit[1]
}

tidy_est <- function(df, div) {
  df <- as.data.frame(df)
  asm <- pick_col(df, c("Assemblage", "Community"), "assemblage")
  ord <- pick_col(df, c("Order.q", "Order"), "order")
  est <- pick_col(df, c(paste0("q", div), "qD"), "estimate")
  data.frame(plant     = as.character(df[[asm]]),
             diversity = div,
             q         = as.numeric(df[[ord]]),
             estimate  = df[[est]],
             coverage  = if ("SC" %in% names(df)) df[["SC"]] else NA_real_,
             method    = if ("Method" %in% names(df)) as.character(df[["Method"]]) else NA_character_,
             stringsAsFactors = FALSE)
}

vals <- bind_rows(tidy_est(est_td, "TD"), tidy_est(est_pd, "PD")) %>%
  left_join(meta[, c("plant", "habitat", "site")], by = "plant")
stopifnot(!anyNA(vals$habitat), nrow(vals) == ncol(comm) * 2 * 3)

message("Methods used: ", paste(names(table(vals$method)), table(vals$method),
                                sep = "=", collapse = ", "))
message("Sample coverage at standardisation depth (TD): ",
        paste(signif(range(vals$coverage[vals$diversity == "TD"], na.rm = TRUE), 4),
              collapse = "-"))

saveRDS(vals, file.path(out_obj_dir, "perplant_hill_size_std.rds"))
write.csv(vals, file.path(out_tab_dir, "perplant_hill_size_std_values.csv"), row.names = FALSE)

# ---- Models: omnibus and post-hoc from the same (additive) model -------------
fit_one <- function(d) {
  d     <- droplevels(d)
  m_int <- lm(log(estimate) ~ habitat * site, data = d)
  m_add <- lm(log(estimate) ~ habitat + site, data = d)

  a_int <- anova(m_add, m_int)
  d1    <- drop1(m_add, test = "F")
  df2   <- df.residual(m_add)

  omnibus <- data.frame(
    term = c("habitat x site (parallelism)", "habitat (adjusted for site)", "site (adjusted for habitat)"),
    df1  = c(a_int$Df[2], d1["habitat", "Df"], d1["site", "Df"]),
    df2  = c(a_int$Res.Df[2], df2, df2),
    F    = c(a_int$F[2], d1["habitat", "F value"], d1["site", "F value"]),
    p    = c(a_int$`Pr(>F)`[2], d1["habitat", "Pr(>F)"], d1["site", "Pr(>F)"]))

  emm <- emmeans(m_add, ~ habitat)
  pw  <- as.data.frame(summary(pairs(emm, adjust = "tukey"), type = "response",
                               infer = c(TRUE, TRUE)))
  trd <- as.data.frame(summary(contrast(emm, "poly"), infer = c(TRUE, TRUE)))
  mm  <- as.data.frame(summary(emm, type = "response"))

  list(omnibus = omnibus, pairwise = pw, trend = trd, emmeans = mm)
}

grid <- unique(vals[, c("diversity", "q")])
res  <- lapply(seq_len(nrow(grid)), function(i) {
  d <- vals[vals$diversity == grid$diversity[i] & vals$q == grid$q[i], ]
  r <- fit_one(d)
  lapply(r, function(x) cbind(diversity = grid$diversity[i], q = grid$q[i], x))
})

omnibus  <- bind_rows(lapply(res, `[[`, "omnibus"))
pairwise <- bind_rows(lapply(res, `[[`, "pairwise"))
trend    <- bind_rows(lapply(res, `[[`, "trend"))
emm_tab  <- bind_rows(lapply(res, `[[`, "emmeans"))

write.csv(omnibus,  file.path(out_tab_dir, "perplant_hill_size_std_omnibus.csv"),  row.names = FALSE)
write.csv(pairwise, file.path(out_tab_dir, "perplant_hill_size_std_pairwise.csv"), row.names = FALSE)
write.csv(trend,    file.path(out_tab_dir, "perplant_hill_size_std_trend.csv"),    row.names = FALSE)
write.csv(emm_tab,  file.path(out_tab_dir, "perplant_hill_size_std_emmeans.csv"),  row.names = FALSE)

# ---- Diagnostic: published unstandardised q = 1 values -----------------------
# Reproduces Tables S14-S15 (Type I, interaction model) and compares with the
# site-adjusted habitat test from the additive model.
diag_tab <- NULL
if (requireNamespace("hillR", quietly = TRUE)) {
  get_hill_phylo <- function(x, tree, qval = 1) {
    out <- tryCatch(hillR::hill_phylo(x, tree = tree, q = qval), error = function(e) NULL)
    if (is.null(out)) out <- hillR::hill_phylo(x, tree, qvalue = qval)
    out
  }
  get_hill_taxa <- function(x, qval = 1) {
    out <- tryCatch(hillR::hill_taxa(x, q = qval), error = function(e) NULL)
    if (is.null(out)) out <- hillR::hill_taxa(x, qvalue = qval)
    out
  }
  cm  <- t(comm)
  raw <- list(TD = get_hill_taxa(cm, 1), PD = get_hill_phylo(cm, tr, 1))
  diag_tab <- bind_rows(lapply(names(raw), function(nm) {
    d <- meta
    d$estimate <- as.numeric(raw[[nm]][d$plant])
    tI <- anova(lm(log(estimate) ~ habitat * site, data = d))
    d1 <- drop1(lm(log(estimate) ~ habitat + site, data = d), test = "F")
    data.frame(diversity = nm, q = 1,
               test = c("Type I habitat, interaction model (published S14-S15)",
                        "habitat adjusted for site, additive model"),
               df1 = c(tI["habitat", "Df"], d1["habitat", "Df"]),
               df2 = c(tI["Residuals", "Df"], df.residual(lm(log(estimate) ~ habitat + site, data = d))),
               F   = c(tI["habitat", "F value"], d1["habitat", "F value"]),
               p   = c(tI["habitat", "Pr(>F)"], d1["habitat", "Pr(>F)"]))
  }))
  write.csv(diag_tab, file.path(out_tab_dir, "perplant_hill_published_typeI_vs_adjusted.csv"),
            row.names = FALSE)
} else {
  message("hillR not installed; published-model diagnostic skipped.")
}

# ---- Console summary --------------------------------------------------------
fmt <- function(x) signif(x, 3)

cat("\n==== Omnibus tests (size-standardised; habitat adjusted for site) ====\n")
print(omnibus %>% mutate(F = fmt(F), p = fmt(p)), row.names = FALSE)

cat("\n==== Tukey pairwise contrasts (ratio of effective diversity) ====\n")
ci_lo <- intersect(c("lower.CL", "asymp.LCL"), names(pairwise))[1]
ci_hi <- intersect(c("upper.CL", "asymp.UCL"), names(pairwise))[1]
print(pairwise %>%
        transmute(diversity, q, contrast, ratio = fmt(ratio),
                  lower = fmt(.data[[ci_lo]]), upper = fmt(.data[[ci_hi]]),
                  p_tukey = fmt(p.value)),
      row.names = FALSE)

cat("\n==== Polynomial contrasts on ordered habitat (log scale) ====\n")
print(trend %>% transmute(diversity, q, contrast, estimate = fmt(estimate), p = fmt(p.value)),
      row.names = FALSE)

if (!is.null(diag_tab)) {
  cat("\n==== Diagnostic: published unstandardised q = 1 values ====\n")
  print(diag_tab %>% mutate(F = fmt(F), p = fmt(p)), row.names = FALSE)
}

cat("\nDone.\n")
